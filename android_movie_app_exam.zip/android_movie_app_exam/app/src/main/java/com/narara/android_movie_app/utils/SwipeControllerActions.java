package com.narara.android_movie_app.utils;

public abstract class SwipeControllerActions {
    public void onLeftClicked(int position) {
    }

    public void onRightClicked(int position) {
    }
}
